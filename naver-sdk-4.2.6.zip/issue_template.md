### Version of naver-login libraries

<!-- 사용하고 있는 네이버 로그인 라이브러리 버전을 적어주세요 -->

### Version of react-native

<!-- 리액트네이티브 버전을 적어주세요 -->

### Platforms you faced the error (IOS or Android or both?)

<!-- 문제가 발생한 플랫폼을 적어주세요 -->

### Expected behavior

<!-- 정상동작 해야 하는 작업을 적어주세요 -->

### Actual behavior

<!-- 겪고 있는 문제 상황을 적어주세요 -->

### Tested environment (Emulator? Real Device?)

<!-- 오류를 겪고 있는 개발환경(에뮬레이터 또는 실제 기기)을 적어주세요 -->
